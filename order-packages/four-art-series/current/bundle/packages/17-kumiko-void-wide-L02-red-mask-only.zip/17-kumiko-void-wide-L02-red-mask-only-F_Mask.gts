%TF.GenerationSoftware,KiCad,Pcbnew,10.0.0*%
%TF.CreationDate,2026-10-08T20:03:21+00:00*%
%TF.ProjectId,17-kumiko-void-wide-L02-red-mask-only,31372d6b-756d-4696-9b6f-2d766f69642d,5*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.0) date 2026-10-08 20:03:21*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,*%
X6500000Y-23600000D03*
%TD*%
%TO.C,*%
X94800000Y-23600000D03*
%TD*%
%TO.C,*%
X6500000Y-104900000D03*
%TD*%
%TO.C,*%
X94800000Y-104900000D03*
%TD*%
M02*
