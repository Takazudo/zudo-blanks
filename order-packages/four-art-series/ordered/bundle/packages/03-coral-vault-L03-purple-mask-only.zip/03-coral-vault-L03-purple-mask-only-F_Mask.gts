%TF.GenerationSoftware,KiCad,Pcbnew,10.0.0*%
%TF.CreationDate,2026-10-08T19:53:51+00:00*%
%TF.ProjectId,03-coral-vault-L03-purple-mask-only,30332d63-6f72-4616-9c2d-7661756c742d,5*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.0) date 2026-10-08 19:53:51*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,*%
X6500000Y-23600000D03*
%TD*%
%TO.C,*%
X94800000Y-23600000D03*
%TD*%
%TO.C,*%
X6500000Y-104900000D03*
%TD*%
%TO.C,*%
X94800000Y-104900000D03*
%TD*%
M02*
